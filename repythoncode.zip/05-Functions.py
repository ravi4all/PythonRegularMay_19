def calc(fno, sno, opr):
    result = eval(fno + opr + sno)
    print(result)

print('''
1. Add
2. Subtract
3. Multiply
4. Divide
''')
ch = input('Enter choice: ')
if int(ch) < 5:
    fno = input('Enter first no: ')
    sno = input('Enter second no: ')
    operations = {'1': '+', '2': '-', '3': '*', '4': '/'}
    operator = operations[ch]
    calc(fno, sno, operator)
else:
    print('Invalid choice')
