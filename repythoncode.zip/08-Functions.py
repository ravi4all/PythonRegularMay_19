def even(n):
    return n%2 == 0


num = [i for i in range(1,51)]
print(num)

#for i in range(1,51):
    #num.append(i)

evenNumbers = list(map(even, num))
print(evenNumbers)

e = []
for n in num:
    if even(n):
        e.append(n)

print(e)

e2 = list(filter(even, num))

print('Even numbers are', e2)

