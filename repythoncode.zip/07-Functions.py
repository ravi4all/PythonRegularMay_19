def temp_convert(c):
    return 9/5 * c + 32

#f = temp_convert(40)
#print(f)

temp = [30, 35, 40]
#f_temp = []

#for t in temp:
    #f = temp_convert(t)
    #print(f)

f_temp = list(map(lambda c : 9/5 * c + 32, temp))
print(f_temp)

#map only works for fns accepting arguments
#f_temp = list(map(temp_convert, temp))
#print(f_temp)
