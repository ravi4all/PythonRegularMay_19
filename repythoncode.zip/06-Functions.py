def outer():
    x = 20
    y = 10
    def inner1():
        return x + y
    def inner2():
        return x - y
    #print(inner1())
    #return inner1(), inner2()
    return inner1, inner2


x = outer()
print('x is',x)
print('Value from First fn is', x[0]())
print('Value from First fn is', outer()[0]())

#inner1()
