def add(x=10,y=20):
    z = x + y
    a = int(input("Enter first number: "))
    b = int(input("Enter second number: "))
    c = a + b
    diff = x - y
    mul = x * y
    return z,c,diff,mul



#result1, result2 = add(10,20)
result1, *result2, result3 = add()  #packing and unpacking, dynamic arguments
print(result1, result2, result3)
add(10,20,30)

