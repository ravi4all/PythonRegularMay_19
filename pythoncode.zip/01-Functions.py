x = 100
y = 200

def add(x=0 , y=0): #fn arguments, default args
    #global x
    #x = 10
    #y = 20
    z = x + y
    print(z)
    print('x', x, 'y', y)

add(200)
add(y)
add(y=200) #mapping arguments
add(z=20)
z = x - y
print(z)
