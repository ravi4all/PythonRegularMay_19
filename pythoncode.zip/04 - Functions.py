def takeInput():
    x = int(input('Enter first number: '))
    y = int(input('Enter second number: '))
    return x,y

def add():
    x,y = takeInput()
    print(x + y)

def sub():
    print(x - y)

def mul():
    print(x * y)

def div():
    print(x / y)

def errorHandler(*args):
    print('Invalid choice...')


print('''
1. Add
2. Sub
3. Mul
4. Div
''')
ch = input("Enter choice: ")

operations = {'1':add, '2':sub, '3':mul, '4':div}
#operations[ch](x,y)
operations.get(ch, errorHandler)()


