#*args
#**keyargs
#if *args is used in arguments they should be at the last position
def emp(*name, position='', salary=0, address=''):
    print(name, position, salary, address)


emp('Mike', 'Developer', 10000, 'Delhi', 'Gurgaon')


def emp2(**details):
    print(details)
    for i in details:
        print(i,details[i])



emp2(name="Mike", salary=10000, dept='IT', pos='Dev', address='Delhi')
